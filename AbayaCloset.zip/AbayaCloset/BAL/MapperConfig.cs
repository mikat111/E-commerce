﻿using AutoMapper;
using BAL.DTOs;
using DAL.EF.Models;

namespace BAL
{
    public class MapperConfig
    {
        static MapperConfiguration cfg = new MapperConfiguration(cfg =>
        {
            // Category
            cfg.CreateMap<Category, CategoryDTO>().ReverseMap();
            
            // Product
            cfg.CreateMap<Product, ProductDTO>().ReverseMap();
            cfg.CreateMap<Product, ProductCreateDTO>().ReverseMap();
            cfg.CreateMap<Product, ProductRecommendationDTO>().ReverseMap();

            // Order
            cfg.CreateMap<Order, OrderCreateDTO>().ReverseMap();

            cfg.CreateMap<Order, OrderDTO>().ReverseMap();
            cfg.CreateMap<OrderItem, OrderItemDTO>().ReverseMap();
        });
        public static Mapper GetMapper()
        {
            return new Mapper(cfg);
        }
    }
}
