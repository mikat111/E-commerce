﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BAL.DTOs
{
    public class OrderCreateDTO 
    {
        public List<OrderItemDTO> Items { get; set; }

        public OrderCreateDTO()
        {
            Items = new List<OrderItemDTO>();
        }

    }
}