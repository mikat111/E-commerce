﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BAL.DTOs
{
    public class OrderDTO
    {
        public int Id { get; set; }
        public DateTime OrderDate { get; set; }
        public List<OrderItemDTO> Items { get; set; }

        public OrderDTO()
        {
            Items = new List<OrderItemDTO>();
        }
    }
}
