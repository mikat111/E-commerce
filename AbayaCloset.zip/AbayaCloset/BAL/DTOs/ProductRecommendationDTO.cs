﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BAL.DTOs
{
    public class ProductRecommendationDTO
    {
        public int Id { get; set; }

        public string Name { get; set; }

        public decimal Price { get; set; }
       
       

    }
}
