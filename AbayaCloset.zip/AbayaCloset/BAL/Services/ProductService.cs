﻿using BAL.DTOs;
using DAL;
using DAL.EF.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace BAL.Services
{
    public class ProductService
    {
        DataAccessFactory factory;

        public ProductService(DataAccessFactory factory)
        {
            this.factory = factory;
        }

        public List<ProductDTO> Get()
        {
            var products = factory.ProductData().Get();
            return MapperConfig.GetMapper().Map<List<ProductDTO>>(products);
        }

        public ProductDTO Get(int id)
        {
            var product = factory.ProductData().Get(id);
            return MapperConfig.GetMapper().Map<ProductDTO>(product);
        }
        public bool Create(ProductCreateDTO dto)
        {
            var product = MapperConfig.GetMapper().Map<Product>(dto);
            return factory.ProductData().Create(product);
        }
        public bool Update(ProductDTO dto)
        {
            var product = MapperConfig.GetMapper().Map<Product>(dto);
            return factory.ProductData().Update(product);
        }

        public bool Delete(int id)
        {
            return factory.ProductData().Delete(id);
        }

        public List<ProductDTO>GetByCategoryAndSimilarPrice(int categoryId, decimal price)
        {
            var products = factory.ProductFeature().GetByCategoryAndSimilarPrice(categoryId, price);
            return MapperConfig.GetMapper().Map<List<ProductDTO>>(products);
        }

        public List<ProductRecommendationDTO> GetByCategoryAndPriceRange(int categoryId, decimal minPrice, decimal maxPrice)
        {
            var products = factory.ProductFeature().GetByCategoryAndPriceRange(categoryId, minPrice, maxPrice);
            return MapperConfig.GetMapper().Map<List<ProductRecommendationDTO>>(products);
        }

        public List<ProductRecommendationDTO> GetLowStockProducts(int threshold)
        {
            var products = factory.ProductFeature().GetLowStockProducts(threshold);
            return MapperConfig.GetMapper().Map<List<ProductRecommendationDTO>>(products);
        }

        //public List<TopSellDTO> GetTopSoldProduct()
        //{
        //    var products = factory.ProductFeature().GetMostSoldProduct();
        //    return MapperConfig.GetMapper().Map<List<TopSellDTO>>(products);

        //}

    }
}
