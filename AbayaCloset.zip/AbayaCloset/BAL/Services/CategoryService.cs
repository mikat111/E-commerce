﻿using BAL.DTOs;
using DAL;
using DAL.EF.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace BAL.Services
{
    public class CategoryService
    {
        DataAccessFactory factory;
        public CategoryService(DataAccessFactory factory)
        {
            this.factory = factory;
        }

        public List<CategoryDTO> Get()
        {
            var data = factory.CategoryData().Get();
            var mapper = MapperConfig.GetMapper();
            var ret = mapper.Map<List<CategoryDTO>>(data);
            return ret;
        }
        public CategoryDTO Get(int id)
        {
            return MapperConfig.GetMapper().Map<CategoryDTO>(factory.CategoryData().Get(id));

        }
        public bool Create(CategoryDTO c)
        {
            var mapper = MapperConfig.GetMapper();
            var data = mapper.Map<Category>(c);
            return factory.CategoryData().Create(data);
        }
        public bool Update(CategoryDTO c)
        {
            var mapper = MapperConfig.GetMapper();
            var data = mapper.Map<Category>(c);
            return factory.CategoryData().Update(data);
        }

        public List<CategoryDTO> FindByName(string name)
        {
            var data = factory.CategoryFeature().FindByName(name);
            var cat = MapperConfig.GetMapper().Map<List<CategoryDTO>>(data);
            return cat;
        }
        public bool Delete(int id)
        {
            return factory.CategoryData().Delete(id);
        }
       
    }
}
