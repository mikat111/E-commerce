﻿using BAL.DTOs;
using DAL;
using DAL.EF.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace BAL.Services
{
    public class OrderService
    {
        DataAccessFactory factory;

        public OrderService(DataAccessFactory factory)
        {
            this.factory = factory;
        }

            public bool Create(OrderCreateDTO c)
            {
            var order = new Order
            {
                OrderDate = DateTime.Now,
              
                OrderItems = new List<OrderItem>()
            };

            foreach (var item in c.Items)
            {
                order.OrderItems.Add(new OrderItem
                {
                    ProductId = item.ProductId,
                    Quantity = item.Quantity
                });
            }

            return factory.OrderData().Create(order);
        }
        public List<OrderDTO> Get()
        {
            var orders = factory.OrderData().Get();
            return MapperConfig.GetMapper().Map<List<OrderDTO>>(orders);
        }
        public OrderDTO Get(int id)
        {
            var order = factory.OrderData().Get(id);
            return MapperConfig.GetMapper().Map<OrderDTO>(order);
        }

        public bool Update(OrderCreateDTO dto)
        {
            var order = MapperConfig.GetMapper().Map<Order>(dto);
            return factory.OrderData().Update(order);
        }
        public bool Delete(int id)
        {
            return factory.OrderData().Delete(id);
        }

    }
}
