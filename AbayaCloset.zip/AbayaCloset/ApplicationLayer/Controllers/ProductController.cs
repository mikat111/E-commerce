﻿using BAL.DTOs;
using BAL.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace ApplicationLayer.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductController : ControllerBase
    {
        ProductService service;
        public ProductController(ProductService service)
        {
            this.service = service;
        }
        [HttpGet("all")]
        public IActionResult All()
        {
            var data = service.Get();
            return Ok(data);
        }
        [HttpGet("{id}")]
        public IActionResult Get(int id)
        {
            var data = service.Get(id);
            return Ok(data);
        }
        [HttpPost("create")]
        public IActionResult Create(ProductCreateDTO c)
        {
            var res = service.Create(c);
            if (res == true)
            {
                return Ok(res);
            }
            else
            {
                return BadRequest(res);
            }
        }
        [HttpPost("update")]
        public IActionResult Update(ProductDTO c)
        {
            var res = service.Update(c);
            if (res == true)
            {
                return Ok(res);
            }
            else
            {
                return BadRequest(res);
            }
        }
        [HttpPost("delete/{id}")]
        public IActionResult Delete(int id)
        {
            var res = service.Delete(id);
            if (res == true)
            {
                return Ok(res);
            }
            else
            {
                return BadRequest(res);
            }
        }
        [HttpGet("lowstock/{threshold}")]
        public IActionResult GetLowStock(int threshold)
        {
            var data = service.GetLowStockProducts(threshold);
            return Ok(data);
        }

        [HttpGet("category/{categoryId}/filtering/{price}")]
        public IActionResult GetByCategoryAndSimilarPrice(int categoryId, decimal price)
        {
            var data = service.GetByCategoryAndSimilarPrice(categoryId, price);
            return Ok(data);
        }

        [HttpGet("category/{categoryId}/recommendation/{minPrice}/{maxPrice}")]
        public IActionResult GetByCategoryAndPriceRange(int categoryId, decimal minPrice, decimal maxPrice)
        {
            var data = service.GetByCategoryAndPriceRange(categoryId, minPrice, maxPrice);
            return Ok(data);
        }

        //[HttpGet("top-sold")]
        //public IActionResult GetTopSold()
        //{
        //    var data = service.GetTopSoldProduct();
        //    return Ok(data);
        //}
    }
}
  