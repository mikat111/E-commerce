﻿using DAL.EF;
using DAL.EF.Models;
using DAL.Interfaces;
using DAL.Repos;
using System;
using System.Collections.Generic;
using System.Text;

namespace DAL
{
    public class DataAccessFactory
    {
        PMSContext db;
        public DataAccessFactory(PMSContext db)
        {
            this.db = db;
        }
        public IRepository<Category> CategoryData()
        {
            return new CategoryRepo(db);
        }
        public ICategoryFeature CategoryFeature()
        {
            return new CategoryRepo(db);
        }
        public IRepository<Product> ProductData()
        { 
            return new ProductRepo(db); 
        }

        public IProductFeature ProductFeature()
        { 
            return new ProductRepo(db); 
        }

        public IRepository<Order> OrderData()
        {
            return new OrderRepo(db);
        }
    }
}
