﻿using DAL.EF.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace DAL.Interfaces
{
    public interface IProductFeature
    {
        List<Product> GetByCategoryAndPriceRange(int categoryId, decimal minPrice, decimal maxPrice);
        List<Product> GetByCategoryAndSimilarPrice(int categoryId, decimal price);
        List<Product> GetLowStockProducts(int threshold);
        //List<Product> GetMostSoldProduct();
    }
}
