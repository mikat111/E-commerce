﻿using DAL.EF.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace DAL.Interfaces
{
    public interface ICategoryFeature
    {
        List<Category> FindByName(string name);
    }
}
