﻿using DAL.EF;
using DAL.EF.Models;
using DAL.Interfaces;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;

namespace DAL.Repos
{
    internal class OrderRepo : IRepository<Order>
    {
        PMSContext db;

        public OrderRepo(PMSContext db)
        {
            this.db = db;
        }
        public bool Create(Order c)
        {
            db.Orders.Add(c);
            return db.SaveChanges() > 0;
        }

        public List<Order> Get()
        {
            return db.Orders
        .Include(o => o.OrderItems)
        .ThenInclude(oi => oi.Product)
        .ToList();
        }

        public Order Get(int id)
        {
            return db.Orders
       .Include(o => o.OrderItems)
       .ThenInclude(oi => oi.Product)
       .FirstOrDefault(o => o.Id == id);
        }

        public bool Update(Order o)
        {
            var ex = Get(o.Id);
            db.Entry(ex).CurrentValues.SetValues(o);
            return db.SaveChanges() > 0;
        }

        public bool Delete(int id)
        {
            var ex = Get(id);
            db.Orders.Remove(ex);
            return db.SaveChanges() > 0;
        }

    }
}

