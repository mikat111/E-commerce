﻿using DAL.EF;
using DAL.EF.Models;
using DAL.Interfaces;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;

namespace DAL.Repos
{
    internal class ProductRepo : IRepository<Product>, IProductFeature
    {
        PMSContext db;

        public ProductRepo(PMSContext db)
        {
            this.db = db;
        }

        public bool Create(Product p)
        {
            db.Products.Add(p);
            return db.SaveChanges() > 0;
        }

        public List<Product> Get()
        {
            return db.Products
                     .Include(p => p.Category)
                     .ToList();
        }
        public Product Get(int id)
        {
          
            return db.Products.Find(id);
        }


        public bool Update(Product p)
        {
            var pro = Get(p.Id);
            db.Entry(pro).CurrentValues.SetValues(p);
            return db.SaveChanges() > 0;
        }

        public bool Delete(int id)
        {
            var pro = db.Products.Find(id);
            if (pro == null) return false;

            db.Products.Remove(pro);
            return db.SaveChanges() > 0;
        }


        public List<Product> GetByCategoryAndPriceRange(int categoryId, decimal minPrice, decimal maxPrice)
        {
            var pro = (from p in db.Products
                       where p.CategoryId == categoryId
                          && p.Price >= minPrice
                          && p.Price <= maxPrice
                       select p).ToList();
            return pro;
        }

        public List<Product> GetByCategoryAndSimilarPrice(int categoryId, decimal price)
        {
            decimal range = 200;

            var pro = (from p in db.Products
                       where p.CategoryId == categoryId
                          && p.Price >= price - range
                          && p.Price <= price + range
                       select p).ToList();
            return pro;
        }
        public List<Product> GetLowStockProducts(int threshold)
        {
            var products = (from p in db.Products
                            where p.Quantity <= threshold
                            select p).ToList();
            return products;
        }

        //public List<Product> GetMostSoldProduct()
        //{
        //    var product = (from p in db.Products
        //                   orderby p.OrderItems.Sum(oi => (int?)oi.Quantity) ?? 0 descending
        //                   select p)
        //                  .ToList();

        //    return product;
        //}



    }
}
