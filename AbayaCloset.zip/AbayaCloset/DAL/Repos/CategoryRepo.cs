﻿using DAL.EF;
using DAL.EF.Models;
using DAL.Interfaces;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;

namespace DAL.Repos
{
    internal class CategoryRepo : IRepository<Category>, ICategoryFeature
    {
        PMSContext db;
        public CategoryRepo(PMSContext db)
        {
            this.db = db;
        }
        public bool Create(Category c)
        {
            db.Categories.Add(c);
            return db.SaveChanges() > 0;
        }
        public List<Category> Get()
        {
            return db.Categories.ToList();
        }  
        public Category Get(int id)
        {
            return db.Categories.Find(id);
        }
        public bool Update(Category c)
        {
            var cat = Get(c.Id);
            db.Entry(cat).CurrentValues.SetValues(c);
            return db.SaveChanges() > 0;
        }
        public bool Delete(int id)
        {
            var cat = Get(id);
            db.Categories.Remove(cat);
            return db.SaveChanges() > 0;
        }
        public List<Category> FindByName(string name)
        {
            var cat = (from c in db.Categories
                       where c.Name.Contains(name)
                       select c).ToList();
            return cat;
        }
    }
}
